# 河洛注音

[台灣方音符號](https://zi-hi.com/%E6%96%B9%E9%9F%B3%E7%AC%A6%E8%99%9F)由台灣省國語推行委員會方言組的朱兆祥教授設計，以注音符號為基礎，
增補國語沒有的發音符號而成。

## 聲母

![方音符號聲母](./docs/static/img/Fong-Im-Siann-Bu.png)

## 韻母

![方音符號韻母](./docs/static/img/Fong-Im-Un-Bu.png)

## 入聲韻尾

![方音符號入聲韻尾](./docs/static/img/Fong-Im-Jip-Siann-Un-Bue.png)

## 聲調

![方音符號聲調](./docs/static/img/Fong-Im-Siann-Tiau.png)
